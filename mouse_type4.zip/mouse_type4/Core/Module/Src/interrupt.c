/*
 * interrupt.c
 *
 *  Created on: Aug 13, 2022
 *      Author: sato1
 */

#include "index.h"
#include "glob_var.h"
#include "rad_accel_table.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{

    if (htim == &htim5){
        Interrupt_PreProcess();
        Interrupt_Main();
        Interrupt_PostProcess();

    }
}

void Interrupt_Initialize(){
	HAL_TIM_Base_Start_IT(&htim5);
}


void Interrupt_PreProcess(){
	//get & calc encoder pulse
	Interrupt_Get_Speed();
	Interrupt_Set_Target_Speed();
}

void Interrupt_Main(){
	//HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
	V_r = V_l = 0.0f;
	motor_out_r = motor_out_l = 0;

	if(run_mode == STRAIGHT_MODE || run_mode == TURN_MODE || run_mode == DIAG_MODE || run_mode == TURN_MODE_TABLE )
	{
		V_r += (target.velo - machine.velo)*velo_g.Kp;
		V_l -= (target.velo - machine.velo)*velo_g.Kp;

		V_r += (target.I_velo - machine.I_velo)*velo_g.Ki;
		V_l -= (target.I_velo - machine.I_velo)*velo_g.Ki;

		V_r += ((target.velo - target.prev_velo) - (machine.velo - machine.prev_velo))*velo_g.Kd;
		V_l -= ((target.velo - target.prev_velo) - (machine.velo - machine.prev_velo))*velo_g.Kd;



		V_r += (target.rad_velo - machine.rad_velo)*omega_g.Kp;
		V_l += (target.rad_velo - machine.rad_velo)*omega_g.Kp;

		V_r += (target.I_rad_velo - machine.I_rad_velo)*omega_g.Ki;
		V_l += (target.I_rad_velo - machine.I_rad_velo)*omega_g.Ki;

		V_r += ((target.rad_velo-target.prev_rad_velo) - (machine.rad_velo-machine.prev_rad_velo))*omega_g.Kd;
		V_l += ((target.rad_velo-target.prev_rad_velo) - (machine.rad_velo-machine.prev_rad_velo))*omega_g.Kd;


	}

	if(run_mode == STRAIGHT_MODE || run_mode == TURN_MODE || run_mode == DIAG_MODE || run_mode == TURN_MODE_TABLE )
	{
		if(ABS(V_r) > 4.0){
			motor_out_r = (int)(SIGN(V_r) * 4.0f * 250.0f);
		}else{
			motor_out_r = (int)(V_r * 250.0f);
		}
		Motor_SetDuty_Right(motor_out_r);

		if(ABS(V_l) > 4.0){
			motor_out_l = (int)(SIGN(V_l) * 4.0f * 250.0f);
		}else{
			motor_out_l = (int)(V_l * 250.0f);
		}
		Motor_SetDuty_Left(motor_out_l);
	}
	else if(run_mode == NON_CON_MODE)
	{
		Motor_SetDuty_Left(0);
		Motor_SetDuty_Right(0);
	}
}

void Interrupt_PostProcess(){
	//IMU_read_DMA_Start();
	//HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);

	if(log_flag)
	{
		log_data[0][time] = target.velo;
		log_data[1][time] = machine.velo;
		log_data[2][time] = target.rad_velo;
		log_data[3][time] = machine.rad_velo;
		time++;
		if(time >= 1000) log_flag = false;
	}
	IMU_read_DMA_Start();
}

void Interrupt_Get_Speed(){
	enc_R.prev_sp_pulse = enc_R.sp_pulse;
	enc_L.prev_sp_pulse = enc_L.sp_pulse;

	enc_R.sp_pulse = Encoder_GetPosition_Right();		Encoder_ResetPosition_Right();
	enc_L.sp_pulse = Encoder_GetPosition_Left();		Encoder_ResetPosition_Left();

	enc_R.prev_wheel_speed = enc_R.wheel_speed;
	enc_L.prev_wheel_speed = enc_L.wheel_speed;

	enc_R.wheel_speed =  (float)enc_R.sp_pulse * MMPP;
	enc_L.wheel_speed =  (float)enc_L.sp_pulse * MMPP;

	machine.prev_velo = machine.velo;
	machine.velo = (enc_R.wheel_speed - enc_L.wheel_speed)/2.0f;
	machine.length += machine.velo;
	machine.I_velo += machine.velo;

	machine.prev_rad_velo = machine.rad_velo;
	machine.rad_velo = (-1.0f)*read_gyro_z_axis()*PI/180.0f;
	machine.radian += machine.rad_velo/1000.0f;
	machine.I_rad_velo += machine.rad_velo;
}

void Interrupt_Set_Target_Speed(){

	target.prev_velo = target.velo;
	target.velo += target.accel/1000.0f;
	if(target.velo >= max_set.velo)
	{
		target.velo = max_set.velo;
		target.accel = 0.0f;
	}
	target.length += target.velo;
	target.I_velo += target.velo;

	if(run_mode == TURN_MODE_TABLE){
		turn_time++;
		if((float)turn_time < set_turn_time * 1000)
		{
			float m =((float)(turn_time))/set_turn_time - (float)((int)(((float)(turn_time))/set_turn_time));
			float n =(float)(((int)(((float)(turn_time))/set_turn_time))+1)- ((float)(turn_time))/set_turn_time;
			target.rad_velo = max_set.rad_velo*(n*accel_table[(int)(((float)(turn_time))/set_turn_time)] + m*accel_table[(int)(((float)(turn_time))/set_turn_time) + 1]);
		}
		else
		{
			target.rad_velo = 0.0;
		}
		target.radian += target.rad_velo/1000.0f;
		target.I_rad_velo += target.rad_velo;
	}
	else
	{
		target.prev_rad_velo = target.rad_velo;
		target.rad_velo += target.rad_accel/1000.0f;
		if(ABS(target.rad_velo) >= ABS(max_set.rad_velo))
		{
			target.rad_velo = max_set.rad_velo;
			target.rad_accel = 0.0f;
		}
		target.radian += target.rad_velo/1000.0f;
		target.I_rad_velo += target.rad_velo;

	}
}
