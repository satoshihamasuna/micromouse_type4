/*
 * run.c
 *
 *  Created on: Aug 13, 2022
 *      Author: sato1
 */

#include "index.h"
#include "glob_var.h"
#include "run_param.h"
#include "rad_accel_table.h"

void Sp_Param_I_Initialize(t_sp_param * sp_param){
	sp_param->I_velo = 0.0f;
	sp_param->I_rad_velo = 0.0f;
	rad_Integral_controller = 0.0f;
}

void Sp_Param_rad_Initialize(t_sp_param * sp_param){
	sp_param->radian = 0.0f;
}


void Sp_Param_Initialize(t_sp_param *sp_param){
	sp_param->accel			= 0.0f;
	sp_param->velo 			= 0.0f;
	sp_param->rad_accel 	= 0.0f;
	sp_param->rad_velo 		= 0.0f;
	sp_param->I_velo		= 0.0f;
	sp_param->I_rad_velo	= 0.0f;
	sp_param->length 		= 0.0f;
	sp_param->radian 		= 0.0f;
}

void Machine_Param_Initialize(){
	machine.accel		= 0.0f;
	machine.velo 		= 0.0f;
    machine.rad_accel 	= 0.0f;
    machine.rad_velo 	= 0.0f;
    machine.I_velo		= 0.0f;
    machine.I_rad_velo	= 0.0f;
    machine.length 		= 0.0f;
    machine.radian 		= 0.0f;
}

void Target_Param_Initialize(){
	target.accel		= 0.0f;
	target.velo 		= 0.0f;
	target.rad_accel 	= 0.0f;
	target.rad_velo 	= 0.0f;
    target.I_velo		= 0.0f;
    target.I_rad_velo	= 0.0f;
	target.length 		= 0.0f;
	target.radian 		= 0.0f;
}

void MAX_Param_Initialize(){
	max_set.accel		= 0.0f;
	max_set.velo 		= 0.0f;
	max_set.rad_accel 	= 0.0f;
	max_set.rad_velo 	= 0.0f;
    max_set.I_velo		= 0.0f;
    max_set.I_rad_velo	= 0.0f;
	max_set.length 		= 0.0f;
	max_set.radian 		= 0.0f;
}

void Set_Velo_PID_Gain(float Kp,float Ki,float Kd){
	velo_g.Kp = Kp;
	velo_g.Ki = Ki;
	velo_g.Kd = Kd;
}

void Set_Omega_PID_Gain(float Kp,float Ki,float Kd){
	omega_g.Kp = Kp;
	omega_g.Ki = Ki;
	omega_g.Kd = Kd;
}

void straight(float len_target,float acc,float max_sp,float end_sp){
	//Machine_Param_Initialize();
	//Target_Param_Initialize();
	//MAX_Param_Initialize();

	Sp_Param_I_Initialize(&machine);
	Sp_Param_I_Initialize(&target);

	if(end_sp == 0.0f)
	{
		run_mode = STRAIGHT_MODE;

		max_set.velo = max_sp;
		max_set.accel = acc;
		target.accel = acc;
		max_set.length = len_target;

		while(max_set.length - machine.length > 1000.0 * (max_set.velo *max_set.velo)/(2.0*max_set.accel));
		target.accel = -acc;
		while(machine.length < max_set.length){
			if(target.velo < 0.0){
				target.accel = 0.0;target.velo = 0.0;
				break;
			}
		}
		target.accel = 0.0;target.velo = 0.0;
		HAL_Delay(100);
		run_mode = NON_CON_MODE;
	}
	else
	{
		run_mode = STRAIGHT_MODE;

		max_set.velo = max_sp;
		max_set.accel = acc;
		target.accel = acc;
		max_set.length = len_target;

		while(max_set.length - machine.length > 1000.0 * (max_set.velo *max_set.velo)/(2.0*max_set.accel));
		target.accel = -acc;
		while(machine.length < max_set.length){
			if(target.velo < end_sp){
				target.accel = 0.0;target.velo = end_sp;
			}
		}
		target.accel = 0.0;target.velo = end_sp;
	}

	machine.length = 0.0;
	target.length =  0.0;
	//run_mode = NON_CON_MODE;

}


void Spin_turn(float rad_target,float rad_acc,float max_rad_velo,t_turn_dir turn_dir){

	Machine_Param_Initialize();
	Target_Param_Initialize();
	MAX_Param_Initialize();

	if(turn_dir == turn_left)
	{
		run_mode = TURN_MODE;
		max_set.rad_velo = max_rad_velo;
		target.rad_accel = rad_acc;
		max_set.rad_accel= rad_acc;
		max_set.radian   = rad_target;
	}
	else if(turn_dir == turn_right)
	{
		run_mode = TURN_MODE;
		max_set.rad_velo = -max_rad_velo;
		target.rad_accel = -rad_acc;
		max_set.rad_accel= -rad_acc;
		max_set.radian   = -rad_target;
	}

	while(ABS(max_set.radian) - ABS(machine.radian) > ABS((max_set.rad_velo*max_set.rad_velo)/(2.0*max_set.rad_accel)));

	if(turn_dir == turn_left)
	{
		target.rad_accel = -rad_acc;
		while(ABS(max_set.radian) > ABS(machine.radian))
		{
			if(target.rad_velo <= 0.0 ){
				max_set.rad_velo = 0.0f;
				target.rad_accel = 0.0f;
				break;
			}
		}
		max_set.rad_velo = 0.0f;
		target.rad_accel = 0.0f;
	}
	else if(turn_dir == turn_right)
	{
		target.rad_accel = rad_acc;
		while(ABS(max_set.radian) > ABS(machine.radian))
		{
			if(target.rad_velo >= 0.0 ){
				max_set.rad_velo = 0.0f;
				target.rad_accel = 0.0f;
				break;
			}
		}
		max_set.rad_velo = 0.0f;
		target.rad_accel = 0.0f;
	}

	HAL_Delay(100);

	machine.radian = 0.0f;
	run_mode = NON_CON_MODE;

}

void turn90(const t_turn_param* param)
{

	Sp_Param_I_Initialize(&target);
	Sp_Param_I_Initialize(&machine);
	Sp_Param_rad_Initialize(&target);
	Sp_Param_rad_Initialize(&machine);

	run_mode = STRAIGHT_MODE;

	max_set.velo = param->velo;
	target.velo  = param->velo;
	max_set.length = param->Lstart;
	while(machine.length < param->Lstart );


	run_mode = TURN_MODE;
	max_set.rad_velo = param->omega;
	target.rad_accel = param->omega_acc;
	max_set.rad_accel= param->omega_acc;
	max_set.radian   = DEG2RAD(param->degree);
	Sp_Param_rad_Initialize(&target);
	Sp_Param_rad_Initialize(&machine);

	while(ABS(max_set.radian) - ABS(target.radian) > ABS((max_set.rad_velo*max_set.rad_velo)/(2.0*max_set.rad_accel)));

	target.rad_accel = (-1.0f)*param->omega_acc;

	while(ABS(max_set.radian) >= ABS(target.radian))
	{
		if(param->turn_dir == turn_left)
		{
			if(target.rad_velo <= 0.0f)
			{
				max_set.rad_velo = 0.0f;
				target.rad_velo = 0.0f;
				target.rad_accel = 0.0f;
				break;
			}
		}
		else if(param->turn_dir == turn_right)
		{
			if(target.rad_velo >= 0.0f)
			{
				max_set.rad_velo = 0.0f;
				target.rad_velo = 0.0f;
				target.rad_accel = 0.0f;
				break;
			}
		}

	}


	run_mode = STRAIGHT_MODE;
	machine.length	= target.length	= 0.0f;
	max_set.velo	= target.velo	= param->velo;
	max_set.length = param->Lend;
	while(machine.length < max_set.length );

	machine.length = target.length  = 0.0f;


}

void turn90_table(const t_turn_param_table* param)
{

	Sp_Param_I_Initialize(&target);
	Sp_Param_I_Initialize(&machine);
	Sp_Param_rad_Initialize(&target);
	Sp_Param_rad_Initialize(&machine);

	run_mode = STRAIGHT_MODE;

	max_set.velo = param->velo;
	target.velo  = param->velo;
	max_set.length = param->Lstart;
	while(machine.length < param->Lstart );


	run_mode = TURN_MODE_TABLE;
	/*
	max_set.rad_velo = param->omega;
	target.rad_accel = param->omega_acc;
	max_set.rad_accel= param->omega_acc;
	max_set.radian   = DEG2RAD(param->degree);
	*/
	max_set.rad_velo = param->velo/(param->r_min/1000);							//rad\s
	set_turn_time = DEG2RAD(param->degree)/(accel_Integral*max_set.rad_velo);	//s

	Sp_Param_rad_Initialize(&target);
	Sp_Param_rad_Initialize(&machine);
	turn_time = 0;

	while((float)turn_time < set_turn_time * 1000);
	max_set.rad_velo = 0.0f;
	target.rad_velo = 0.0f;
	target.rad_accel = 0.0f;

	run_mode = STRAIGHT_MODE;
	machine.length	= target.length	= 0.0f;
	max_set.velo	= target.velo	= param->velo;
	max_set.length = param->Lend;
	while(machine.length < max_set.length );

	machine.length = target.length  = 0.0f;


}


void long_turn90(const t_turn_param* param)
{

}

void long_turn180(const t_turn_param* param)
{

}

void turn_v90(const t_turn_param *param)
{

}

void turn_in(const t_turn_param *param)
{

}

void turn_out(const t_turn_param *param)
{

}
