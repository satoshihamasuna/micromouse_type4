/*
 * operation_check.c
 *
 *  Created on: 2022/08/14
 *      Author: sato1
 */
#include "index.h"
#include "run_param.h"
#include "run_param.h"
#include "glob_var.h"
void slalom_check_R90()
{
		 log_flag = true;time = 0;
		 Sp_Param_Initialize(&machine);
		 Sp_Param_Initialize(&target);
		 Sp_Param_Initialize(&max_set);
		 straight(45.0f, 4.0f, 0.3f, 0.3f);
		 turn90(&slalom_R90_search);
		 straight(45.0f, 4.0f, 0.3f, 0.0f);
		 log_flag = false;
}
void slalom_check_L90()
{
	 	 log_flag = true;time = 0;
	 	 Sp_Param_Initialize(&machine);
	 	 Sp_Param_Initialize(&target);
	 	 Sp_Param_Initialize(&max_set);
	 	 straight(45.0f, 4.0f, 0.3f, 0.3f);
	 	 //turn90(&slalom_L90_search);
	 	 turn90_table(&slalom_L90_table);turn90_table(&slalom_L90_table);turn90_table(&slalom_L90_table);turn90_table(&slalom_L90_table);
	 	 turn90_table(&slalom_L90_table);turn90_table(&slalom_L90_table);turn90_table(&slalom_L90_table);turn90_table(&slalom_L90_table);
	 	 straight(45.0f, 4.0f, 0.3f, 0.0f);
	 	 log_flag = false;
}

void slalom_fast_L90()
{
	 	 log_flag = true;time = 0;
	 	 Sp_Param_Initialize(&machine);
	 	 Sp_Param_Initialize(&target);
	 	 Sp_Param_Initialize(&max_set);
	 	 straight(90.0f, 10.0f, 1.0f, 1.0f);
	 	 //turn90(&slalom_L90_v3);
	 	 turn90_table(&slalom_L90_table_v3);
	 	 straight(90.0f, 10.0f, 1.0f, 0.0f);
	 	 log_flag = false;
}

void fast_run_check()
{
		 log_flag = true;time = 0;
		 Sp_Param_Initialize(&machine);
		 Sp_Param_Initialize(&target);
		 Sp_Param_Initialize(&max_set);
		 straight(270.0f, 15.0f, 2.0f, 0.0f);
		 log_flag = false;
}
