/*
 * glob_var.h
 *
 *  Created on: Aug 13, 2022
 *      Author: sato1
 */

#include "typedef.h"

#ifndef MODULE_INC_GLOB_VAR_H_
#define MODULE_INC_GLOB_VAR_H_
#define GLOBAL
#else
#define GLOBAL extern
#endif

GLOBAL t_encoder enc_R,enc_L;
GLOBAL uint8_t mouse_mode;
GLOBAL t_bool is_mode_enable;

GLOBAL uint8_t run_mode;

GLOBAL t_sp_param machine;
GLOBAL t_sp_param target;
GLOBAL t_sp_param max_set;

GLOBAL t_pid_gain velo_g;
GLOBAL t_pid_gain omega_g;

GLOBAL float V_r;
GLOBAL float V_l;
GLOBAL float velo_Integral_controller;
GLOBAL float rad_Integral_controller;
GLOBAL int motor_out_r;
GLOBAL int motor_out_l;

GLOBAL float log_data[4][1000];
GLOBAL t_bool log_flag;
GLOBAL uint32_t time;

/* MODULE_INC_GLOB_VAR_H_ */
