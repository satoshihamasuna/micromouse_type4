/*
 * typedef.h
 *
 *  Created on: Aug 13, 2022
 *      Author: sato1
 */

#include "macro.h"

#ifndef MODULE_INC_TYPEDEF_H_
#define MODULE_INC_TYPEDEF_H_

typedef enum{
	 false = 0,
	 true  = 1,
}t_bool;

typedef struct{
	int32_t sp_pulse;
	int32_t prev_sp_pulse;
	float 	wheel_speed;
	float	prev_wheel_speed;
}t_encoder;

typedef enum{
	sensor_fl = 3,
	sensor_fr = 4,
	sensor_sl = 1,
	sensor_sr = 2,
}t_sensor_dir;

typedef enum{
	front = 0,
	right = 1,
	rear  = 2,
	left  = 3,
}t_local_dir;

typedef struct{
	t_bool front;
	t_bool right;
	t_bool rear;
	t_bool left;
}t_local_wall;

typedef enum{
	north = 0,
	east  = 1,
	south = 2,
	west  = 3,
}t_direction;

typedef enum{
	x_axis = 0,
	y_axis = 1,
	z_axis = 2,
}t_axis;

typedef enum{
	turn_left	= LEFT,
	turn_right 	= RIGHT,
}t_turn_dir;


typedef struct{
	short x;
	short y;
	t_direction dir;
}t_position;

typedef struct{
	unsigned char north : 2;
	unsigned char east  : 2;
	unsigned char south : 2;
	unsigned char west  : 2;
}t_wall;

typedef struct{
	uint16_t value;
	t_bool parity;
	uint8_t prev_node_x;
	uint8_t prev_node_y;
	t_direction prev_node_d;
	t_local_dir run_pattern;
}t_node_el;

typedef struct{
	float velo;
	float omega;
	float omega_acc;
	float Lstart;
	float Lend;
	float degree;
	t_turn_dir turn_dir;
}t_turn_param;

typedef struct{
	float velo;
	float r_min;
	float Lstart;
	float Lend;
	float degree;
	t_turn_dir turn_dir;
}t_turn_param_table;

typedef struct{
	float velo;
	float prev_velo;
	float I_velo;
	float accel;
	float rad_velo;
	float prev_rad_velo;
	float I_rad_velo;
	float rad_accel;
	float length;
	float radian;
}t_sp_param;

typedef struct{
	float Kp;
	float Ki;
	float Kd;
}t_pid_gain;

typedef struct{
	t_turn_param_table pram;
	t_pid_gain sp_gain;
	t_pid_gain om_gain;
}t_param;

#endif /* MODULE_INC_TYPEDEF_H_ */
