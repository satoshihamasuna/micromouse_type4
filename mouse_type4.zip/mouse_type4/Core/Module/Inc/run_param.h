/*
 * run_pram.c
 *
 *  Created on: Aug 13, 2022
 *      Author: sato1
 */

#ifndef MODULE_INC_RUN_PRAM_C_
#define MODULE_INC_RUN_PRAM_C_

#include "typedef.h"
#include "macro.h"

const static t_turn_param sla_neta_R90_v0 = {0.5, -6.0*PI, -200*PI, 10.87, 10.87, -90.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param sla_neta_L90_v0 = {0.5, 6.0*PI,  200*PI,  10.87, 10.87,  90.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/

const static t_turn_param slalom_R90_search = {0.3f, -4.0f*PI, -80.0f*PI, 14.3f,14.3f,-90.0, RIGHT};
const static t_turn_param slalom_L90_search = {0.3f,  4.0f*PI,  80.0f*PI, 14.3f,14.3f, 90.0, LEFT };


const static t_turn_param slalom_R90_v0 = {0.3, -3.0*PI, -60*PI, 50.57, 50.29, -90.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_L90_v0 = {0.3,	 3.0*PI,  60*PI, 50.57, 50.29,  90.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_R90_v1 = {0.5, -4.0*PI, -80*PI,	37.10, 37.10, -90.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_L90_v1 = {0.5,	4.0*PI,  80*PI, 37.10, 37.10,  90.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_R90_v2 = {0.75, -5.0*PI, -120*PI, 27.24, 24.72, -90.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_L90_v2 = {0.75,  5.0*PI,  120*PI, 27.24, 24.72,  90.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_R90_v3 = {1.0, -7.0*PI, -250*PI, 30.404, 29.280, -90.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_L90_v3 = {1.0,  7.0*PI,  250*PI, 30.404, 29.280,  90.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/

const static t_turn_param slalom_R180_v0 = {0.3, -2.15*PI, -28*PI, 34.18, 34.18, -180.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_L180_v0 = {0.3,  2.15*PI,  28*PI, 34.18, 34.18,  180.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_R180_v1 = {0.5, -3.43*PI, -80*PI, 34.56, 34.56, -180.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_L180_v1 = {0.5,  3.43*PI,  80*PI, 34.56, 34.56,  180.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_R180_v2 = {0.75, -5.2*PI, -120*PI, 28.36, 28.36, -180.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_L180_v2 = {0.75,  5.2*PI,  120*PI, 28.36, 28.36,  180.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/

const static t_turn_param slalom_RV90_v0 = {0.3,  -3.0*PI, -60*PI, 24.13, 23.93, -90.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_LV90_v0 = {0.3,   3.0*PI,  60*PI, 24.13, 23.93,  90.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_RV90_v1 = {0.5,  -4.0*PI, -80*PI, 11.93, 11.93, -90.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_LV90_v1 = {0.5,   4.0*PI,  80*PI, 11.93, 11.93,  90.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_RV90_v2 = {0.75,  -5.8*PI, -200*PI, 11.47, 10.55, -90.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_LV90_v2 = {0.75,   5.8*PI,  200*PI, 11.47, 10.55,  90.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/

const static t_turn_param slalom_inR45_v0 = {0.3, -2.5*PI, -50*PI,	21.59, 40.23, -45.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_inL45_v0 = {0.3,  2.5*PI,  50*PI,  21.59, 40.23,  45.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_inR45_v1 = {0.5, -4.0*PI, -80*PI,	15.4, 33.76, -45.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_inL45_v1 = {0.5,  4.0*PI,  80*PI,  15.4, 33.76,  45.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/

const static t_turn_param slalom_inR135_v0 = {0.3, -2.5*PI, -25*PI,	25.50, 17.78, -135.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_inL135_v0 = {0.3,	2.5*PI,  25*PI, 25.50, 17.78,  135.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_inR135_v1 = {0.5, -4.0*PI, -80*PI,	27.96, 19.60+3.535, -135.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_inL135_v1 = {0.5,	4.0*PI,  80*PI, 27.96, 19.60+3.535,  135.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_inR135_v2 = {0.75,-5.8*PI, -150*PI, 21.074, 11.6258, -135.0, RIGHT};
const static t_turn_param slalom_inL135_v2 = {0.75, 5.8*PI,  150*PI, 21.074, 11.6258,  135.0, LEFT };


const static t_turn_param slalom_outR45_v0 = {0.3, -2.5*PI, -50*PI,	40.23, 21.59, -45.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_outL45_v0 = {0.3,  2.5*PI,  50*PI, 40.23, 21.59,  45.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_outR45_v1 = {0.5, -4.0*PI, -80*PI,	34.678+3.535, 15.4, -45.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_outL45_v1 = {0.5,	4.0*PI,  80*PI, 34.678+3.535, 15.4,  45.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/



const static t_turn_param slalom_outR135_v0 = {0.3, -2.5*PI, -25*PI, 17.78, 25.50, -135.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_outL135_v0 = {0.3,	 2.5*PI,  25*PI, 17.78, 25.50,  135.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_outR135_v1 = {0.5, -4.0*PI, -80*PI, 19.60+3.535, 27.96, -135.0, RIGHT};/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_outL135_v1 = {0.5,	 4.0*PI,  80*PI, 19.60+3.535, 27.96,  135.0, LEFT };/*	float velo;float omega;float omega_acc;float Lstart;float Lend;*/
const static t_turn_param slalom_outR135_v2 = {0.75,-5.8*PI, -150*PI, 11.6258, 21.074, -135.0, RIGHT};
const static t_turn_param slalom_outL135_v2 = {0.75, 5.8*PI,  150*PI, 11.6258, 21.074,  135.0, LEFT};

const static t_turn_param_table slalom_L90_table = {0.30f,25.0f,11.0,11.0,90.0f,LEFT};
const static t_turn_param_table slalom_L90_table_v3 = {1.0f,48.0f,25.0,25.0,90.0f,LEFT};

//const t_turn_param_table L90 = {0.30f,25.0f,11.0,11.0,90.0f,LEFT};
//const t_pid_gain		 L90_velo_gain = {1.0,0.2,0.0f};
//const t_pid_gain		 L90_rad_gain = {1.0,0.2,0.0f};
//static t_param p ={L90,L90_velo_gain,L90_rad_gain};

#endif /* MODULE_INC_RUN_PRAM_C_ */
