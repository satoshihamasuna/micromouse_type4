/*
 * operation_check.h
 *
 *  Created on: 2022/08/14
 *      Author: sato1
 */

#ifndef MODULE_INC_OPERATION_CHECK_H_
#define MODULE_INC_OPERATION_CHECK_H_

#include "index.h"
#include "run_param.h"

void slalom_check_R90();
void slalom_check_L90();
void slalom_fast_L90();
void fast_run_check();

#endif /* MODULE_INC_OPERATION_CHECK_H_ */
